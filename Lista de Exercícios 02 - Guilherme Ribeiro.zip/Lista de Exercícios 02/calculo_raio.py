raio = float(input("Informe o valor do raio da circunferência: "))

area = 3.14 * (raio * raio)

print(f"A área da circunfência é de: {area}")