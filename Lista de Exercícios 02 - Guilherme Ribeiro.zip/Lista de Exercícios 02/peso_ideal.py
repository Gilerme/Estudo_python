altura = float(input("Digite sua Altura: "))

homem = (72.7 * altura) - 58 #calculo do peso de homem e mulher 
mulher = (62.1 * altura) - 44.7

print(f"Com essa altura, o peso ideal caso seja homem é: {homem}\n E caso seja mulher é: {mulher}")